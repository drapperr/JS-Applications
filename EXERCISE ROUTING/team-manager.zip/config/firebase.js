const firebaseConfig = {
    apiKey: "AIzaSyBZz2-h3r_birnkKM67P8L7A59KplGD9Jw",
    authDomain: "myexam-05.firebaseapp.com",
    databaseURL: "https://myexam-05.firebaseio.com",
    projectId: "myexam-05",
    storageBucket: "myexam-05.appspot.com",
    messagingSenderId: "640468188220",
    appId: "1:640468188220:web:31d53bfcb31abedef91739"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
import user from './user.js';
import catalog from './catalog.js';

export default{
    user,
    catalog
};
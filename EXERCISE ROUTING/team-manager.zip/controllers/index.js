import user from './user.js';
import home from './home.js';
import catalog from './catalog.js';

export default{
    user,
    home,
    catalog
};